

public interface GraphInterface<T> extends BasicGraphInterface<T>, GraphAlgorithmsInterface<T>{

    
}